stags is a branch of ctags-5.8, special for symfind.
by Liang, Jian
2013/6

> build
Make on win32 (use mingw) and linux, then rename ctags/ctags.exe to stags/stags.exe.
Then strip the exe to reduce the size.
